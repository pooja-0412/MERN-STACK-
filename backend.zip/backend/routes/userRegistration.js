const express = require('express');
const router = express.Router();
const User = require('../models/user'); // Assuming you have a user model

// Save user registration details
// Save user registration details
router.post('/register', async (req, res) => {
    try {
        const { username, phone, address, paymentMethod, orderDetails } = req.body;

        // Validate input
        if (!username || !phone || !address || !paymentMethod || !orderDetails || orderDetails.length === 0) {
            return res.status(400).json({ message: 'Please fill in all fields and provide ordered items' });
        }

        const newUser = new User({ username, phone, address, paymentMethod, orderDetails });
        await newUser.save();
        res.status(200).json({ message: 'Account created successfully' });
    } catch (error) {
        console.error('Error registering user:', error);
        res.status(500).json({ message: 'Failed to register user', error: error.message });
    }
});

module.exports = router;
