const express = require('express');
const router = express.Router();
const Product = require('../models/Product');

// Get all products
router.get('/', async (req, res) => {
    try {
        const products = await Product.find(); // Fetch all products from the database
        res.status(200).json(products);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching products', error: error.message });
    }
});

// Save new products
router.post('/', async (req, res) => {
    try {
        const newProducts = await Product.insertMany(req.body);
        res.status(201).json({ message: 'Products saved successfully', products: newProducts });
    } catch (error) {
        res.status(500).json({ message: 'Failed to save products', error: error.message });
    }
});

module.exports = router;
