// routes/orderItems.js
const express = require('express');
const router = express.Router();
const Order = require('../models/Order');

// Fetch all orders (order history)
router.get('/history', async (req, res) => {
    try {
        const orders = await Order.find(); // Fetch all orders from the database
        res.status(200).json(orders); // Send back the orders
    } catch (error) {
        res.status(500).json({ message: 'Failed to fetch order history', error: error.message });
    }
});

// Save selected items to the database as an order
router.post('/', async (req, res) => {
    try {
        const { items } = req.body; // Extract items from the request body

        // Create a new order with the items
        const newOrder = new Order({ items });

        // Save the order to the database
        const savedOrder = await newOrder.save();

        // Respond with a success message and the saved order
        res.status(201).json({ message: 'Order placed successfully', order: savedOrder });
    } catch (error) {
        console.error('Error saving order:', error);
        res.status(500).json({ message: 'Failed to place order', error: error.message });
    }
});

// Update an existing order by ID
router.put('/:id', async (req, res) => {
    const { id } = req.params;
    const { items } = req.body;

    try {
        const updatedOrder = await Order.findByIdAndUpdate(
            id,
            { items },
            { new: true, runValidators: true }
        ); // Update order items

        if (!updatedOrder) {
            return res.status(404).json({ message: 'Order not found' });
        }

        res.status(200).json({ message: 'Order updated successfully', order: updatedOrder });
    } catch (error) {
        res.status(500).json({ message: 'Failed to update order', error: error.message });
    }
});

module.exports = router;
