const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors'); // Import CORS
const orderRoutes = require('./routes/orderItems');
const productRoutes = require('./routes/productRoutes');
const userRoutes = require('./routes/userRegistration');
const app = express();
const PORT = process.env.PORT || 5002;

// Middleware
app.use(cors()); // Enable CORS
app.use(bodyParser.json()); // Parse JSON requests

app.use('/api/orderitems', orderRoutes);
app.use('/api/products', productRoutes);
app.use('/api/users', userRoutes); // Add this line for user routes
// MongoDB connection
mongoose.connect('mongodb://localhost:27017/malathi', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
        console.log('MongoDB connected');
        app.listen(PORT, () => {
            console.log(`Server is running on http://localhost:${PORT}`);
        });
    })
    .catch(err => console.error('MongoDB connection error:', err));
