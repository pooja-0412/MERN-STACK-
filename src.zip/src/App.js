import React, { useState } from 'react';
import { Route, Routes, Navigate, useLocation } from 'react-router-dom';
import './App.css';

import { Navbar } from './components/Navbar';
import { Home, Shop, Account } from './components/pages';
import { BlueberryDetail } from './components/pages/BlueberryDetail';
import { Vegetabledetails } from './components/pages/Vegetabledetails';
import { Fruitdetail } from './components/pages/Fruitdetail';
import OfferDetails from './components/pages/OfferDetails';
import { Login } from './components/pages/Login';
import { Favorites } from './components/pages/Favorites';
import OrderHistory from './components/pages/OrderHistory'; 
import Explore from './components/pages/Explore'; 

const App = () => {
    const [favorites, setFavorites] = useState([]);
    const location = useLocation(); // Get current route

    // Determine if the current path is the Explore page
    const isExplorePage = location.pathname === '/explore';

    return (
        <div className="App">
            {/* Conditionally render Navbar based on the current route */}
            {!isExplorePage && <Navbar />}
            
            <Routes>
                <Route path="/" element={<Navigate to="/explore" />} /> {/* Default to Explore page */}
                <Route path="/explore" element={<Explore />} /> {/* Explore route */}
                <Route path="/home" element={<Home setFavorites={setFavorites} />} />
                <Route path="/shop" element={<Shop />} />
                <Route path="/account" element={<Account />} />
                <Route path="/blueberry" element={<BlueberryDetail />} />
                <Route path="/vegetabledetails" element={<Vegetabledetails />} />
                <Route path="/fruitdetail" element={<Fruitdetail />} />
                <Route path="/offerdetails" element={<OfferDetails />} />
                <Route path="/login" element={<Login />} />
                <Route path="/favorites" element={<Favorites favorites={favorites} />} />
                <Route path="/order-history" element={<OrderHistory />} />
            </Routes>
        </div>
    );
};

export default App;
