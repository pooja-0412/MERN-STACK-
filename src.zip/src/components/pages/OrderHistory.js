// src/components/OrderHistory.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const OrderHistory = () => {
    const [orders, setOrders] = useState([]);
    const [editOrder, setEditOrder] = useState(null); // Track which order is being edited

    useEffect(() => {
        const fetchOrders = async () => {
            try {
                const response = await axios.get('http://localhost:5001/api/orderitems/history');
                setOrders(response.data); // Set the orders fetched from the backend
            } catch (error) {
                console.error('Error fetching order history:', error);
                alert('Failed to fetch order history');
            }
        };

        fetchOrders(); // Call the function to fetch orders on component mount
    }, []);

    const handleQuantityChange = (orderId, itemIndex, newQuantity) => {
        const updatedOrders = orders.map(order => {
            if (order._id === orderId) {
                const updatedItems = order.items.map((item, idx) =>
                    idx === itemIndex ? { ...item, quantity: newQuantity } : item
                );
                return { ...order, items: updatedItems };
            }
            return order;
        });
        setOrders(updatedOrders);
    };

    const handleUpdateOrder = async (orderId) => {
        const orderToUpdate = orders.find(order => order._id === orderId);
        try {
            const response = await axios.put(`http://localhost:5001/api/orderitems/${orderId}`, {
                items: orderToUpdate.items,
            });
            alert('Order updated successfully');
            setEditOrder(null); // Reset edit mode
        } catch (error) {
            console.error('Error updating order:', error);
            alert('Failed to update order');
        }
    };

    return (
        <div className="order-history-container">
            <h2>Order History</h2>
            {orders.length > 0 ? (
                <ul>
                    {orders.map((order, index) => (
                        <li key={index}>
                            <h4>Order {index + 1}</h4>
                            <ul>
                                {order.items.map((item, idx) => (
                                    <li key={idx}>
                                        {item.name} - ₹{item.price} x 
                                        {editOrder === order._id ? (
                                            <input
                                                type="number"
                                                value={item.quantity}
                                                onChange={(e) =>
                                                    handleQuantityChange(order._id, idx, Number(e.target.value))
                                                }
                                            />
                                        ) : (
                                            item.quantity
                                        )}
                                    </li>
                                ))}
                            </ul>
                            <p><strong>Date:</strong> {new Date(order.date).toLocaleString()}</p>

                            {editOrder === order._id ? (
                                <button onClick={() => handleUpdateOrder(order._id)}>Save Changes</button>
                            ) : (
                                <button onClick={() => setEditOrder(order._id)}>Edit Order</button>
                            )}
                        </li>
                    ))}
                </ul>
            ) : (
                <p>No orders found!</p>
            )}
        </div>
    );
};

export default OrderHistory;
