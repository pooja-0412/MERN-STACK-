import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';


const ExplorePage = () => {
    const [showExploreMessage, setShowExploreMessage] = useState(true);
    const navigate = useNavigate();

    const handleExploreClick = () => {
        setShowExploreMessage(false);
        setTimeout(() => {
            navigate('/home');
        }, ); // 2 seconds delay
    };

    return (
        <div className="explore-container">
            {showExploreMessage && (
                <div className="explore-content">
                    <div className="welcome-message">
                        <h1>Welcome to Our Shop</h1>
                        
                    </div>
                    <div className="explore-message">
                        <h1>Fruits & Vegetables</h1>
                        <p>Your one-stop shop for fresh produce!</p>
                        <button className="btn explore-btn" onClick={handleExploreClick}>
                            Explore Now
                        </button>
                    </div>
                    <div className="floating-images">
                        <img src="water.jpg" alt="Apple" className="fruit-image" />
                        <img src="greenchilly.jpg" alt="Banana" className="fruit-image" />
                        <img src="jackfruit.jpg" alt="Tomato" className="fruit-image" />
                    </div>
                </div>
            )}
        </div>
    );
};

export default ExplorePage;
