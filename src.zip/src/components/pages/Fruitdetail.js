import React from 'react';

export const Fruitdetail = () => {
    const Fruit = [
        {
            id: 1,
            name: 'FRUIT: WATERMELON',
            description: 'Juicy, refreshing, and packed with hydration, watermelons are perfect for cooling down on hot summer days. Rich in vitamins A and C.',
            discount: '25',
            image: 'water.jpg',
        },
        {
            id: 2,
            name: 'FRUIT: BANANA',
            description: 'Fresh, ripe bananas are a natural source of energy, high in potassium and dietary fiber. Great for a quick snack or smoothie base.',
            discount: '24%',
            image: 'banana.jpg',
        },
        {
            id: 3,
            name: 'FRUIT: POMEGRANATE',
            description: 'Bright red, juicy, and sweet with a hint of tartness. Pomegranates are rich in antioxidants and are known for their numerous health benefits.',
            discount: '25',
            image: 'gram.jpg',
        },
        {
            id: 4,
            name: 'FRUIT: BLUEBERRY',
            description: 'Small, round, and packed with antioxidants, blueberries are known to boost heart health and improve brain function.',
            discount: '22',
            image: 'blueberry.jpg',
        },
        {
            id: 9,
            name: 'FRUIT: GUAVA',
            description: 'This tropical fruit is rich in vitamin C and fiber, with a delightful balance of sweetness and tartness in every bite.',
            discount: '43',
            image: 'guava.jpg',
        },
        {
            id: 10,
            name: 'FRUIT: APPLE',
            description: 'Crisp, sweet, and high in dietary fiber, apples are a classic snack that promote digestive health and overall wellness.',
            discount: '45',
            image: 'apple.jpg',
        },
        {
            id: 11,
            name: 'FRUIT: ORANGE',
            description: 'Bright, juicy, and full of vitamin C, oranges are perfect for boosting immunity and refreshing your palate with a tangy flavor.',
            discount: '40',
            image: 'oranges.jpg',
        },
        {
            id: 12,
            name: 'FRUIT: PAPAYA',
            description: 'Sweet and soft, papayas are rich in enzymes that aid digestion and are packed with vitamins A and C, making them perfect for your daily diet.',
            discount: '40',
            image: 'pappaya.jpg',
        },
        {
            id: 13,
            name: 'FRUIT: GRAPES',
            description: 'These juicy, bite-sized fruits are great for snacking and are known to support heart health thanks to their high antioxidant content.',
            discount: '37',
            image: 'grapes.jpg',
        },
        {
            id: 14,
            name: 'FRUIT: AVOCADO',
            description: 'Creamy and nutrient-dense, avocados are a great source of healthy fats and fiber, perfect for salads, spreads, and even smoothies.',
            discount: '40',
            image: 'avocado.jpg',
        },
        {
            id: 15,
            name: 'FRUIT: STRAWBERRY',
            description: 'Bright red, juicy, and packed with vitamins, strawberries are delicious in desserts, smoothies, or eaten fresh as a snack.',
            discount: '40',
            image: 'starberry.jpg',
        },
        {
            id: 16,
            name: 'FRUIT: RAMBUTAN',
            description: 'This exotic fruit is known for its sweet, juicy flesh and hairy outer shell. A tropical delight packed with vitamin C and antioxidants.',
            discount: '42',
            image: 'rambutan.jpg',
        },
        {
            id: 17,
            name: 'FRUIT: MANGOSTEEN',
            description: 'Known as the "queen of fruits," mangosteens are sweet and tangy, loaded with nutrients and antioxidants.',
            discount: '43% OFF',
            image: 'Mangosteen.jpg',
        },
        {
            id: 18,
            name: 'FRUIT: CHERRY',
            description: 'Sweet and tart, cherries are perfect for desserts or as a healthy snack. They are rich in antioxidants and promote sleep.',
            discount: '44',
            image: 'cherry.jpg',
        },
        {
            id: 19,
            name: 'FRUIT: PEAR',
            description: 'Sweet, juicy, and fragrant, pears are a great source of fiber and vitamin C, perfect for a quick, nutritious snack.',
            discount: '43',
            image: 'pear.jpg',
        },
        {
            id: 20,
            name: 'FRUIT: FIG',
            description: 'Sweet and chewy, figs are packed with fiber and minerals like calcium and magnesium. They make a healthy, natural snack.',
            discount: '43',
            image: 'fig.jpg',
        },
        {
            id: 22,
            name: 'FRUIT: LEMON',
            description: 'Tart and tangy, lemons are a versatile fruit used for flavoring dishes, drinks, and are rich in vitamin C.',
            discount: '40F',
            image: 'lemon.jpg',
        },
        {
            id: 35,
            name: 'FRUIT: PLUM',
            description: 'Sweet and tangy, plums are perfect for snacking, baking, or making jams. They are rich in vitamins and antioxidants.',
            discount: '33F',
            image: 'plum.jpg',
        },
        {
            id: 36,
            name: 'FRUIT: GRAPEFRUIT',
            description: 'Known for its tangy flavor, grapefruits are packed with vitamin C and antioxidants, helping to boost your immune system.',
            discount: '33',
            image: 'grape fruit.jpg',
        },
        {
            id: 44,
            name: 'FRUIT: QUINCE',
            description: 'Aromatic and tart, quinces are often used in jellies and jams. They are high in fiber and vitamin C.',
            discount: '22',
            image: 'quince.jpg',
        },
        {
            id: 44,
            name: 'FRUIT: RASPBERRY',
            description: 'Sweet, tangy, and packed with antioxidants, raspberries are perfect for snacking or adding to smoothies.',
            discount: '28',
            image: 'raspberry.jpg',
        },
        {
            id: 45,
            name: 'FRUIT: KIWI',
            description: 'Sweet and tangy with a unique flavor and vibrant green flesh, kiwis are rich in vitamin C and dietary fiber.',
            discount: '29',
            image: 'kiwi.jpg',
        },
        {
            id: 46,
            name: 'FRUIT: JACKFRUIT',
            description: 'Large and tropical, jackfruits have a sweet, unique flavor and a fibrous texture. They are rich in vitamins and antioxidants.',
            discount: '20',
            image: 'jackfruit.jpg',
        },
    ];

    return (
        <div className="ac">
            <h1>Welcome to Our Fruit Collection</h1><br></br>
            <p>Explore our wide variety of fresh, delicious fruits. Packed with nutrition and available at discounted rates.</p>
<br></br>
            {/* Subheading for the fruit list */}
            <h2>List of Fruits with Discounts</h2>
            <div className="c">
                <div className="rows">
                    {Fruit.map((ft) => (
                        <div key={ft.id} className="colum">
                            <div className="cards">
                                <div className="icr">
                                    <img src={ft.image} alt={ft.name} className="cardimg" />
                                    <div className="discount">{ft.discount}% OFF</div>
                                </div>
                                <div className="cardb">
                                    <div className="name">{ft.name}</div>
                                    <div className="description">{ft.description}</div>
                                    
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default Fruitdetail;
