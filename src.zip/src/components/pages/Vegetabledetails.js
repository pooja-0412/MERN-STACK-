import React from 'react';

export const Vegetabledetails = () => {
    const Vegetables = [
        {
            id: 5,
            name: 'VEGETABLE: CABBAGE',
            description: 'Fresh and crunchy cabbage, rich in fiber and vitamins. Perfect for salads, stir-fries, or even pickling. It adds a mild flavor and crisp texture to your meals.',
            discount: '40% OFF',
            image: 'cabbage.jpg',
        },
        {
            id: 6,
            name: 'VEGETABLE: MUSHROOM',
            description: 'Tender and flavorful mushrooms, high in antioxidants and low in calories. Great for soups, pasta, stir-fries, or as a meat substitute in vegetarian dishes.',
            discount: '40% OFF',
            image: 'mushroom.jpg',
        },
        {
            id: 7,
            name: 'VEGETABLE: CHILLI',
            description: 'Spicy and vibrant green chillies, known for adding heat to dishes. Packed with vitamins A and C, they are perfect for spicing up curries, chutneys, and pickles.',
            discount: '47% OFF',
            image: 'chile.jpg',
        },
        {
            id: 8,
            name: 'VEGETABLE: CAPSICUM',
            description: 'Crunchy and colorful capsicum, rich in vitamins C and A. Perfect for salads, stir-fries, grilling, or as a topping for pizzas and sandwiches.',
            discount: '40% OFF',
            image: 'colour chile.jpg',
        },
        {
            id: 21,
            name: 'VEGETABLE: GINGER',
            description: 'Spicy and fragrant ginger, essential for adding zest to your cooking. Known for its anti-inflammatory properties, it’s perfect for curries, teas, and marinades.',
            discount: '33% OFF',
            image: 'Ginger.jpg',
        },
        {
            id: 22,
            name: 'FRUIT: LEMON',
            description: 'Tart and tangy lemons, high in vitamin C. Ideal for flavoring dishes, making refreshing beverages, or adding zest to your baking.',
            discount: '40% OFF',
            image: 'lemon.jpg',
        },
        {
            id: 23,
            name: 'VEGETABLE: CARROT',
            description: 'Sweet and crunchy carrots, loaded with beta-carotene and antioxidants. Great for snacking, salads, or cooking in soups, stews, and stir-fries.',
            discount: '33% OFF',
            image: 'carrots.jpg',
        },
        {
            id: 24,
            name: 'VEGETABLE: GREEN CHILLY',
            description: 'Spicy and flavorful green chillies, perfect for adding heat and spice to your dishes. They are packed with vitamins and minerals.',
            discount: '33% OFF',
            image: 'greenchilly.jpg',
        },
        {
            id: 25,
            name: 'VEGETABLE: BITTERGOURD',
            description: 'Bitter yet nutritious bitter gourd, known for its health benefits. Ideal for stir-fries, soups, or making traditional Indian dishes.',
            discount: '30% OFF',
            image: 'bittergourd.jpg',
        },
        {
            id: 26,
            name: 'VEGETABLE: LADIES FINGER',
            description: 'Also known as okra, this crunchy vegetable is perfect for curries, stir-fries, or as a crispy fried snack. Rich in fiber and vitamins.',
            discount: '55% OFF',
            image: 'ladiesfinger.jpg',
        },
        {
            id: 27,
            name: 'VEGETABLE: BEANS',
            description: 'Nutritious and versatile beans, packed with protein and fiber. They are great in salads, soups, and as a side dish for main meals.',
            discount: '40% OFF',
            image: 'beans.jpg',
        },
        {
            id: 28,
            name: 'VEGETABLE: BEETROOT',
            description: 'Sweet and earthy beetroot, perfect for salads, juices, or roasting. Known for its vibrant color and nutritional benefits, high in fiber and antioxidants.',
            discount: '30% OFF',
            image: 'beetroot.jpg',
        },
        {
            id: 29,
            name: 'VEGETABLE: BRINJAL',
            description: 'Soft and versatile brinjal (eggplant), perfect for roasting, grilling, or making rich curries. It’s a great source of dietary fiber.',
            discount: '33% OFF',
            image: 'brinjal.jpg',
        },
        {
            id: 30,
            name: 'VEGETABLE: SNOW PEAS',
            description: 'Sweet and crisp snow peas, ideal for stir-fries, salads, or as a crunchy snack. They are a good source of fiber and vitamins.',
            discount: '25% OFF',
            image: 'snowpea.jpg',
        },
        {
            id: 31,
            name: 'VEGETABLE: ONION',
            description: 'A staple in most dishes, onions are great for adding flavor to soups, stews, curries, and salads. Rich in antioxidants and essential nutrients.',
            discount: '37% OFF',
            image: 'onion.jpg',
        },
        {
            id: 32,
            name: 'VEGETABLE: RED RADISH',
            description: 'Crisp and spicy red radishes, perfect for adding a fresh crunch to salads and snacks. They are low in calories and high in vitamin C.',
            discount: '33% OFF',
            image: 'redraddish.jpg',
        },
        // Add more vegetables here with detailed descriptions
    ];

    return (
        <div className="ac">
                        <h1>Welcome to Our Product Collection</h1>
            <p>Explore our fresh, nutritious vegetables, all available at discounted rates.</p>


            <div className="c">
                <div className="rows">
                    {Vegetables.map((veg) => (
                        <div key={veg.id} className="colum">
                            <div className="cards">
                                <div className="icr">
                                    <img src={veg.image} alt={veg.name} className="cardimg" />
                                    <div className="discount">{veg.discount}</div>
                                </div>
                                <div className="cardb">
                                    <div className="name">{veg.name}</div>
                                    <div className="description">{veg.description}</div>
                                    
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default Vegetabledetails;
