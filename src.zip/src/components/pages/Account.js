import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import axios from 'axios';

export const Account = () => {
    const [username, setUsername] = useState('');
    const [phone, setPhone] = useState('');
    const [address, setAddress] = useState('');
    const [paymentMethod, setPaymentMethod] = useState('Offline Payment');
    const navigate = useNavigate();
    const location = useLocation();
    const orderDetails = location.state?.orderDetails || [];
    
    // Prepare an array of selected item IDs and details
    const orderedItemDetails = orderDetails.map(item => ({
        productId: item._id, // Assuming each item has an _id property
        name: item.name,
        price: item.price,
        quantity: item.quantity,
    }));

    const handleRegister = async () => {
        if (!username || !phone || !address) {
            alert('Please fill in all fields');
            return;
        }
    
        // Validate phone number length
        if (phone.length < 10) {
            alert('Phone number must be at least 10 digits long');
            return;
        }
    
        console.log("User Registration Details:", { username, phone, address, paymentMethod, orderedItemDetails });
        try {
            const response = await axios.post('http://localhost:5002/api/users/register', {
                username,
                phone,
                address,
                paymentMethod,
                orderDetails: orderedItemDetails, // Send ordered items with details
            });
            alert(response.data.message);
            navigate('/login', { state: { orderDetails } });
        } catch (error) {
            alert('Failed to create account: ' + (error.response?.data?.message || 'An error occurred'));
        }
    };
    

    return (
        <div className="login-container">
            <div className="login-left">
                <img src="page.jpg" alt="Description of the image" className="malathi" />
            </div>
            <div className="login-right">
                <h2>User Registration</h2>
                <input 
                    type="text" 
                    placeholder="Username" 
                    value={username} 
                    onChange={(e) => setUsername(e.target.value)} 
                />
                <input 
                    type="text" 
                    placeholder="Phone Number" 
                    value={phone} 
                    onChange={(e) => setPhone(e.target.value)} 
                />
                <input 
                    type="text" 
                    placeholder="Address" 
                    value={address} 
                    onChange={(e) => setAddress(e.target.value)} 
                />
                <div className="payment-method">
                    <label>
                        <input
                            type="radio"
                            value="Offline Payment"
                            checked={paymentMethod === 'Offline Payment'}
                            onChange={() => setPaymentMethod('Offline Payment')}
                        />
                        Offline Payment
                    </label>
                    <label>
                        <input
                            type="radio"
                            value="Online Payment"
                            checked={paymentMethod === 'Online Payment'}
                            onChange={() => setPaymentMethod('Online Payment')}
                        />
                        Online Payment
                    </label>
                </div>
                <button className="btn btn-primary" onClick={handleRegister}>Register</button>

                {/* Display ordered item names and details */}
                <h3>Ordered Items:</h3>
                <ul>
                    {orderDetails.map(item => (
                        <li key={item._id}>
                            {item.name} (Quantity: {item.quantity}, Price: ${item.price})
                        </li>
                    ))}
                </ul>
            </div>
        </div>
    );
};

export default Account;
