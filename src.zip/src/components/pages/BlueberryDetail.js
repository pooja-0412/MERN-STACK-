import React from 'react';

export const BlueberryDetail = () => {
  return (
    <div className="product-container">
      <div className="product-header">
        <h2>Blueberry Premium [Imported]</h2>
        <p>125 gm - ₹319 (20% off)</p>
      </div>

      <div className="product-image">
        <img src="https://via.placeholder.com/200" alt="Blueberries" />
      </div>

      <div className="product-description">
        <h3>Description</h3>
        <p>
          Blueberries are round with a slightly flattened top and bottom. They are covered in deep purple and smooth skin.
          These little berries bring you a fantastic mix of sweet, tart, and fruity flavors.
        </p>
      </div>

      <div className="product-storage">
        <h3>Shelf Life and Storage</h3>
        <p>
          Blueberries have a shelf life of up to 2-3 days. Store them in a breathable container with air circulation to
          avoid moisture buildup and prevent mold growth.
        </p>
      </div>

      <div className="product-nutrition">
        <h3>Nutritional Value (Per 100 gms)</h3>
        <ul>
          <li>Calories: 57</li>
          <li>Carbohydrates: 14.5g</li>
          <li>Fiber: 2.4g</li>
          <li>Sugars: 9.96g</li>
          <li>Protein: 0.74g</li>
          <li>Potassium: 77mg</li>
        </ul>
      </div>

      <div className="product-benefits">
        <h3>Health Benefits</h3>
        <ul>
          <li>Power-packed with antioxidants that help fight aging and chronic diseases.</li>
          <li>Good for heart health by helping lower blood pressure and cholesterol levels.</li>
          <li>Rich in fiber, which aids digestion and improves gut health.</li>
        </ul>
      </div>

      <div className="product-usage">
        <h3>How to Enjoy Your Blueberries</h3>
        <p>
          You can enjoy blueberries raw, or pair them with yogurt, smoothies, or fruit salads. They're also great in pies,
          cheesecakes, jams, and more.
        </p>
      </div>
    </div>
  );
};
