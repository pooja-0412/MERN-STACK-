import React from 'react';
import { useLocation } from 'react-router-dom';

export const Login = () => {
    const location = useLocation();
    const orderDetails = location.state?.orderDetails || [];

    return (
        <div className="login-message login-background">
           
            {orderDetails.length > 0 ? (
                <div>
                    <h2 className="order-header">Your Order Has Been Placed!</h2>
                    <p className="message">Thank you for your purchase! Your order is being processed.</p>
                    <h3 className="order-details-header">Order Details:</h3>
                    
                    {/* Order Cards with Animation */}
                    <div className="order-cards-container" style={{ display: 'flex', flexWrap: 'wrap', gap: '20px' }}>
                        {orderDetails.map((item, index) => (
                            <div 
                                key={item.productId} 
                                className={`order-card fade-in`} // Add fade-in class for animation
                                style={{ ...cardStyle, animationDelay: `${index * 0.2}s` }} // Delay each card animation
                            >
                                <div className="order-card-info">
                                    <h4 style={{ margin: '0 0 10px', fontSize: '18px' }}>{item.name}</h4>
                                    <p style={{ margin: '0', fontSize: '16px' }}>Quantity: <strong>{item.quantity}</strong></p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            ) : (
                <p className="message">No recent orders placed.</p>
            )}
        </div>
    );
};

// Styling for order card
const cardStyle = {
    border: '1px solid #ddd',
    borderRadius: '8px',
    padding: '15px',
    width: '200px',
    boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
    textAlign: 'center',
    backgroundColor: 'lightblue',
    transition: 'transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out',
};

export default Login;
