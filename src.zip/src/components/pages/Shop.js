import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

export const Shop = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const [selectedFruits, setSelectedFruits] = useState([]);

    const fruits = [
        {
            id: 1,
            name: 'FRUIT: WATERMELON',
            description: 'Juicy, refreshing, and packed with a sweet flavor, perfect for summer hydration.',
            size: '1 Kg',
            price: 150,
            originalPrice: 200,
            discount: '25% OFF',
            image: 'water.jpg',
        },
        {
            id: 2,
            name: 'FRUIT: BANANA',
            description: 'Fresh, ripe bananas with a natural sweet taste.',
            size: '1 Kg',
            price: 68, // Current price per kilogram in INR
            originalPrice: 90, // Original price per kilogram in INR
            discount: '24% OFF', // Calculated discount based on the current price
            image: 'banana.jpg', // Add your banana image path
          
        },
        
        // You can add more fruit objects here if needed
        {
            id: 3,
            name: 'FRUIT: POMEGRANATE',
            description: 'Bright red, juicy, and sweet with a hint of tartness',
            size: '150 Gm',
            price: 300, // Updated current price
            originalPrice: 400,
            discount: '25% OFF', // Updated discount
            image: 'gram.jpg', // Update the image path if needed
        
        },
        {
            id: 4,
            name: 'FRUIT: BLUEBERRY',
            description: 'Small, round, and sweet, rich in antioxidants',
            size: '150 Gm',
            price: 350, // Updated current price
            originalPrice: 450,
            discount: '22% OFF', // Updated discount
            image: 'blueberry.jpg', // Add your blueberry image path
           
        },
        
        {
            id: 5,
            name: 'VEGETABLE: CABBAGE',
            description: 'Fresh and crunchy, perfect for salads and stir-fries',
            size: '500 Gm', // Adjusted size
            price: 120, // Current market rate
            originalPrice: 200,
            discount: '40% OFF',
            image: 'cabbage.jpg',
           
        },
        {
            id: 6,
            name: 'VEGETABLE: MUSHROOM',
            description: 'Tender and flavorful, great for soups and dishes',
            size: '250 Gm', // Adjusted size
            price: 150, // Current market rate
            originalPrice: 250,
            discount: '40% OFF',
            image: 'mushroom.jpg',
          
        },
        
        {
            id: 7,
            name: 'VEGETABLE: CHILLI',
            description: 'Spicy and vibrant, perfect for adding heat to dishes',
            size: '100 Gm', // Adjusted size
            price: 80, // Current market rate
            originalPrice: 150,
            discount: '47% OFF',
            image: 'chile.jpg',
        
        },
        {
            id: 8,
            name: 'VEGETABLE: CAPSICUM',
            description: 'Crunchy and colorful, great for salads and stir-fries',
            size: '200 Gm', // Adjusted size
            price: 120, // Current market rate
            originalPrice: 200,
            discount: '40% OFF',
            image: 'colour chile.jpg', // Updated image path
          
        },
        
        {
            id: 9,
            name: 'FRUIT: GUAVA',
            description: 'Bright red, juicy, and sweet with a hint of tartness',
            size: '150 Gm',
            price: 200, // Current market rate
            originalPrice: 350,
            discount: '43% OFF',
            image: 'guava.jpg', // Image path remains unchanged
           
        },
        {
            id: 10,
            name: 'FRUIT: APPLE',
            description: 'Crisp and sweet, perfect for snacking or baking',
            size: '150 Gm',
            price: 220, // Current market rate
            originalPrice: 400,
            discount: '45% OFF',
            image: 'apple.jpg', // Image path remains unchanged
          
        },
        
        {
            id: 11,
            name: 'FRUIT: ORANGE',
            description: 'Bright and juicy with a sweet flavor',
            size: '150 Gm',
            price: 180, // Current market rate
            originalPrice: 300,
            discount: '40% OFF',
            image: 'oranges.jpg', // Image path remains unchanged
         
        },
        {
            id: 12,
            name: 'FRUIT: PAPAYA',
            description: 'Sweet and soft, perfect for desserts or smoothies',
            size: '150 Gm',
            price: 150, // Current market rate
            originalPrice: 250,
            discount: '40% OFF',
            image: 'pappaya.jpg', // Image path remains unchanged
           
        },
        {
            id: 13,
            name: 'FRUIT: GRAPES',
            description: 'Sweet and juicy, perfect for snacking',
            size: '150 Gm',
            price: 220, // Current market rate
            originalPrice: 350,
            discount: '37% OFF',
            image: 'grapes.jpg', // Image path remains unchanged
            
        },
        {
            id: 14,
            name: 'FRUIT: AVOCADO',
            description: 'Creamy and rich, great for salads and spreads',
            size: '150 Gm',
            price: 300, // Current market rate
            originalPrice: 500,
            discount: '40% OFF',
            image: 'avocado.jpg', // Image path remains unchanged
        
        },
        
        {
            id: 15,
            name: 'FRUIT: STRAWBERRY',
            description: 'Bright red, juicy, and sweet with a hint of tartness',
            size: '0.5 Kg', // Changed size to kg
            price: 300, // Current market rate
            originalPrice: 500,
            discount: '40% OFF',
            image: 'starberry.jpg', // Image path remains unchanged
        
        },
        {
            id: 16,
            name: 'FRUIT: RAMBUTAN',
            description: 'Sweet and juicy with a unique texture',
            size: '0.5 Kg', // Changed size to kg
            price: 350, // Current market rate
            originalPrice: 600,
            discount: '42% OFF',
            image: 'rambutan.jpg', // Image path remains unchanged
          
        },
        {
            id: 17,
            name: 'FRUIT: MANGOSTEEN',
            description: 'Sweet and tangy, known as the "queen of fruits"',
            size: '0.5 Kg', // Changed size to kg
            price: 400, // Current market rate
            originalPrice: 700,
            discount: '43% OFF',
            image: 'Mangosteen.jpg', // Image path remains unchanged
          
        },
        {
            id: 18,
            name: 'FRUIT: CHERRY',
            description: 'Sweet and tart, perfect for desserts and snacks',
            size: '0.5 Kg', // Changed size to kg
            price: 450, // Current market rate
            originalPrice: 800,
            discount: '44% OFF',
            image: 'cherry.jpg', // Image path remains unchanged
      
        },
        
        {
            id: 19,
            name: 'FRUIT: PEAR',
            description: 'Sweet, juicy, and fragrant with a hint of tartness',
            size: '0.5 Kg', // Changed size to kg
            price: 200, // Current market rate
            originalPrice: 350,
            discount: '43% OFF',
            image: 'pear.jpg', // Image path remains unchanged
            
        },
        {
            id: 20,
            name: 'FRUIT: FIG',
            description: 'Sweet, chewy, and rich in flavor',
            size: '0.5 Kg', // Changed size to kg
            price: 400, // Current market rate
            originalPrice: 700,
            discount: '43% OFF',
            image: 'fig.jpg', // Image path remains unchanged
            
        },
        {
            id: 21,
            name: 'VEGETABLE: GINGER',
            description: 'Spicy and fragrant, perfect for cooking',
            size: '0.5 Kg', // Changed size to kg
            price: 100, // Current market rate
            originalPrice: 150,
            discount: '33% OFF',
            image: 'Ginger.jpg', // Image path remains unchanged
            
        },
        {
            id: 22,
            name: 'FRUIT: LEMON',
            description: 'Tart and tangy, great for flavoring dishes',
            size: '0.5 Kg', // Changed size to kg
            price: 150, // Current market rate
            originalPrice: 250,
            discount: '40% OFF',
            image: 'lemon.jpg', // Image path remains unchanged
          
        },
        {
            id: 23,
            name: 'VEGETABLE: CARROT',
            description: 'Sweet, crunchy, and great for salads',
            size: '0.5 Kg', // Changed size to kg
            price: 80, // Current market rate
            originalPrice: 120,
            discount: '33% OFF',
            image: 'carrots.jpg', // Image path remains unchanged
         
        },
        {
            id: 24,
            name: 'VEGETABLE: GREEN CHILLY',
            description: 'Spicy and flavorful, adds heat to dishes',
            size: '0.5 Kg', // Changed size to kg
            price: 100, // Current market rate
            originalPrice: 150,
            discount: '33% OFF',
            image: 'greenchilly.jpg', // Image path remains unchanged
          
        },
        {
            id: 25,
            name: 'VEGETABLE: BITTERGOURD',
            description: 'Bitter yet nutritious, great for health',
            size: '0.5 Kg', // Changed size to kg
            price: 70, // Current market rate
            originalPrice: 100,
            discount: '30% OFF',
            image: 'bittergourd.jpg', // Image path remains unchanged
            
        },
        {
            id: 26,
            name: 'VEGETABLE: LADIES FINGER',
            description: 'Crunchy and slightly sweet, perfect for curries',
            size: '0.5 Kg', // Changed size to kg
            price: 90, // Current market rate
            originalPrice: 130,
            discount: '31% OFF',
            image: 'ladiesfinger.jpg', // Image path remains unchanged
            
        },
        {
            id: 27,
            name: 'VEGETABLE: BEANS',
            description: 'Nutritious and versatile, great in salads',
            size: '0.5 Kg', // Changed size to kg
            price: 120, // Current market rate
            originalPrice: 200,
            discount: '40% OFF',
            image: 'beans.jpg', // Image path remains unchanged
            
        },
        {
            id: 28,
            name: 'VEGETABLE: BEETROOT',
            description: 'Sweet and earthy, great for salads and juices',
            size: '0.5 Kg', // Changed size to kg
            price: 70, // Current market rate
            originalPrice: 100,
            discount: '30% OFF',
            image: 'beetroot.jpg', // Image path remains unchanged
            
        },
        {
            id: 29,
            name: 'VEGETABLE: BRINJAL',
            description: 'Soft and versatile, perfect for many dishes',
            size: '0.5 Kg', // Changed size to kg
            price: 80, // Current market rate
            originalPrice: 120,
            discount: '33% OFF',
            image: 'brinjal.jpg', // Image path remains unchanged
           
        },
        {
            id: 30,
            name: 'VEGETABLE: SNOW PEAS',
            description: 'Sweet and crisp, perfect for stir-fries',
            size: '0.5 Kg', // Changed size to kg
            price: 150, // Current market rate
            originalPrice: 200,
            discount: '25% OFF',
            image: 'snowpea.jpg', // Image path remains unchanged
            
        },
        {
            id: 31,
            name: 'VEGETABLE: ONION',
            description: 'A staple ingredient, great for flavoring',
            size: '0.5 Kg', // Changed size to kg
            price: 50, // Current market rate
            originalPrice: 80,
            discount: '37% OFF',
            image: 'onion.jpg', // Image path remains unchanged
            
        },
        {
            id: 32,
            name: 'VEGETABLE: RED RADISH',
            description: 'Crisp and spicy, great in salads',
            size: '0.5 Kg', // Changed size to kg
            price: 60, // Current market rate
            originalPrice: 90,
            discount: '33% OFF',
            image: 'redraddish.jpg', // Image path remains unchanged
           
        },
        {
            id: 33,
            name: 'VEGETABLE: PINEAPPLE',
            description: 'Sweet and tangy, great for snacking',
            size: '0.5 Kg', // Changed size to kg
            price: 100, // Current market rate
            originalPrice: 150,
            discount: '33% OFF',
            image: 'pineapple.jpg', // Image path remains unchanged
      
        },
        {
            id: 34,
            name: 'VEGETABLE: GREEN BANANA',
            description: 'Sweet and tangy, great for snacking',
            size: '0.5 Kg', // Size remains in kg
            price: 100, // Current market rate
            originalPrice: 150,
            discount: '33% OFF',
            image: 'green-banana.jpg', // Image path remains unchanged
            
        },
        {
            id: 35,
            name: 'FRUIT: PLUM',
            description: 'Sweet and tangy, great for snacking',
            size: '200 Gm', // Changed size to Gm
            price: 100, // Current market rate
            originalPrice: 150,
            discount: '33% OFF',
            image: 'plum.jpg', // Image path remains unchanged
           
        },
        {
            id: 36,
            name: 'FRUIT: GRAPEFRUIT',
            description: 'Sweet and tangy, great for snacking',
            size: '300 Gm', // Changed size to Gm
            price: 100, // Current market rate
            originalPrice: 150,
            discount: '33% OFF',
            image: 'grape fruit.jpg', // Updated image path for clarity
           
        },
        {
            id: 37,
            name: 'VEGETABLE:CORN',
            description: 'Sweet and tangy, great for snacking',
            size: '300 Gm', // Changed size to Gm
            price: 100, // Current market rate
            originalPrice: 150,
            discount: '33% OFF',
            image: 'CORN.jpg', // Updated image path for clarity
           
        },
        {
            id: 38,
            name: 'VEGETABLE: CAULIFLOWER',
            description: 'Fresh and crisp, perfect for a variety of dishes',
            size: '1 Kg', // Current standard size in kg
            price: 80, // Current market rate
            originalPrice: 120,
            discount: '33% OFF',
            image: 'cauliflower.jpg', // Image path remains unchanged
           
        },
        {
            id: 39,
            name: 'VEGETABLE: PUMPKIN',
            description: 'Rich in flavor, ideal for soups and curries',
            size: '1.5 Kg', // Common size in kg
            price: 60, // Current market rate
            originalPrice: 90,
            discount: '33% OFF',
            image: 'pumpkin.jpg', // Image path remains unchanged
           
        },
        
        {
            id: 40,
            name: 'VEGETABLE: POTATO',
            description: 'Versatile vegetable, perfect for boiling, frying, or mashing',
            size: '1 Kg', // Common size in kg
            price: 30, // Current market rate
            originalPrice: 45,
            discount: '33% OFF',
            image: 'potato.jpg', // Image path remains unchanged
           
        },
        {
            id: 41,
            name: 'VEGETABLE: SWEET POTATO',
            description: 'Naturally sweet, ideal for baking, roasting, or boiling',
            size: '1 Kg', // Common size in kg
            price: 50, // Current market rate
            originalPrice: 70,
            discount: '29% OFF',
            image: 'sweetpotato.jpg', // Image path remains unchanged
           
        },
        {
            id: 41,
            name: 'VEGETABLE: RED CHILI',
            description: 'Spicy and flavorful, perfect for adding heat to dishes',
            size: '0.5 Kg', // Common size in kg for chili
            price: 120, // Current market rate
            originalPrice: 150,
            discount: '20% OFF',
            image: 'redchili.jpg', // Image path remains unchanged
            
        },
        {
            id: 42,
            name: 'VEGETABLE: RED CABBAGE',
            description: 'Spicy and flavorful, perfect for adding heat to dishes',
            size: '0.5 Kg', // Common size in kg for chili
            price: 120, // Current market rate
            originalPrice: 150,
            discount: '20% OFF',
            image: 'redcabbage.jpg', // Image path remains unchanged
            
        },
        {
            id: 43,
            name: 'VEGETABLE: GARLIC',
            description: 'Aromatic and flavorful, used in a variety of dishes',
            size: '0.5 Kg', // Common size in kg for garlic
            price: 200, // Current market rate
            originalPrice: 250,
            discount: '20% OFF',
            image: 'garlic.jpg', // Image path remains unchanged
          
        },
        {
            id: 44,
            name: 'FRUIT: QUINCE',
            description: 'Aromatic and tart, often used in jellies and jams',
            size: '1 Kg', // Common size for quince
            price: 350, // Current market rate
            originalPrice: 450,
            discount: '22% OFF',
            image: 'quince.jpg', // Image path remains unchanged
           
        },
        {
            id: 44,
            name: 'FRUIT: RASPBERRY',
            description: 'Sweet, tangy, and packed with antioxidants',
            size: '250 Gm', // Common size for raspberries
            price: 300, // Current market rate
            originalPrice: 400,
            discount: '25% OFF',
            image: 'raspberry.jpg', // Image path remains unchanged
           
        },
        {
            id: 45,
            name: 'FRUIT: KIWI',
            description: 'Sweet and tangy with a unique flavor and vibrant green flesh',
            size: '200 Gm', // Common size for kiwis
            price: 250, // Current market rate
            originalPrice: 350,
            discount: '29% OFF',
            image: 'kiwi.jpg', // Image path remains unchanged
            
        },
        {
            id: 46,
            name: 'FRUIT: JACKFRUIT',
            description: 'Large, tropical fruit with a sweet, unique flavor and a fibrous texture',
            size: '1 Kg', // Common size for jackfruit
            price: 800, // Current market rate
            originalPrice: 1000,
            discount: '20% OFF',
            image: 'jackfruit.jpg', // Image path remains unchanged
           
        },

        // Add more fruit objects as needed...
    ];

    // Load previously selected fruits from the Favorites page
    useEffect(() => {
        if (location.state && location.state.selectedFruits) {
            setSelectedFruits(location.state.selectedFruits); // Load previously selected fruits
        }
    }, [location]);

    const handleAddToFavorites = (fruit) => {
        setSelectedFruits((prev) => [...prev, fruit]);
        alert(`${fruit.name} added to favorites!`); // Show prompt message
    };

    const handlePlaceOrder = () => {
        navigate('/favorites', { state: { selectedFruits } });
        setSelectedFruits([]); // Clear selections after moving to favorites
    };

    return (
        <div className="container">
            <h2>Shop Seasonal Fruits and Vegetables</h2>
            <div className="row" style={{ display: 'flex', justifyContent: 'flex-start' }}>
                {fruits.map((fruit) => (
                    <div className="col" key={fruit.id} style={{ margin: '10px' }}>
                        <div className="card p-3" style={{ width: '300px' }}>
                            <div className="image-container" style={{ textAlign: 'center' }}>
                                <img
                                    className="card-img-top"
                                    src={process.env.PUBLIC_URL + '/' + fruit.image}
                                    alt={fruit.name}
                                    style={{ width: '100%' }}
                                />
                                {fruit.discount && <div className="discount">{fruit.discount}</div>}
                            </div>
                            <div className="card-body">
                                <h4 className="card-title">{fruit.name}</h4>
                                <p className="description">{fruit.description}</p>
                                <p className="size">{fruit.size}</p>
                                <p className="price">Price: ₹{fruit.price}</p>
                                <button className="btn btn-primary" onClick={() => handleAddToFavorites(fruit)}>
                                    Add To Favorites
                                </button>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
            <button className="btn btn-primary" onClick={handlePlaceOrder} style={{ marginTop: '20px' }}>
                Go to Favorites
            </button>
        </div>
    );
};

export default Shop;
