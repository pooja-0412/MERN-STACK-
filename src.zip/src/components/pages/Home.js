import React, { useState } from 'react';
import { Link } from 'react-router-dom';

export const Home = ({ setFavorites }) => {
    const [favorites, setFavoritesLocal] = useState([]);

    const addToFavorites = (item) => {
        // Avoid adding duplicates to favorites
        if (!favorites.some(fav => fav.id === item.id)) {
            setFavoritesLocal([...favorites, item]);
            setFavorites((prevFavorites) => [...prevFavorites, item]);
        } else {
            alert('Item already in favorites!');
        }
    };

    const fruits = [
        {
            id: 1,
            name: 'FRUIT: BLUEBERRY',
            description: 'Small, round, and sweet, rich in antioxidants',
            size: '150 Gm',
            price: 350,
            originalPrice: 450,
            discount: '22% OFF',
            image: 'blueberry.jpg',
            link: '/blueberry'
        },
        {
            id: 2,
            name: 'FRUIT: BANANA',
            description: 'Fresh, ripe bananas with a natural sweet taste.',
            size: '1 Kg',
            price: 68,
            originalPrice: 90,
            discount: '24% OFF',
            image: 'banana.jpg',
            link: '/banana'
        },
        {
            id: 3,
            name: 'VEGETABLE: MUSHROOM',
            description: 'Tender and flavorful, great for soups and dishes',
            size: '250 Gm',
            price: 150,
            originalPrice: 250,
            discount: '40% OFF',
            image: 'mushroom.jpg',
            link: '/mushroom'
        },
        {
            id: 4,
            name: 'FRUIT: STRAWBERRY',
            description: 'Bright red, juicy, and sweet with a hint of tartness',
            size: '0.5 Kg',
            price: 300,
            originalPrice: 500,
            discount: '40% OFF',
            image: 'starberry.jpg',
            link: '/strawberry'
        },
        {
            id: 5,
            name: 'VEGETABLE: CARROT',
            description: 'Sweet, crunchy, and great for salads',
            size: '0.5 Kg',
            price: 80,
            originalPrice: 120,
            discount: '33% OFF',
            image: 'carrots.jpg',
            link: '/carrot'
        },
        {
            id: 6,
            name: 'VEGETABLE: CORN',
            description: 'Sweet and tangy, great for snacking',
            size: '300 Gm',
            price: 100,
            originalPrice: 150,
            discount: '33% OFF',
            image: 'corn.jpg',
            link: '/corn'
        },
        {
            id: 7,
            name: 'FRUIT: CHILE',
            description: 'Spicy and flavorful, great for adding heat to dishes',
            size: '150 Gm',
            price: 250,
            originalPrice: 400,
            discount: '37% OFF',
            image: 'chile.jpg',
            link: '/chile'
        },
        {
            id: 8,
            name: 'FRUIT: COLOUR CHILE',
            description: 'Bright and spicy, perfect for salsas',
            size: '150 Gm',
            price: 250,
            originalPrice: 400,
            discount: '37% OFF',
            image: 'colour chile.jpg',
            link: '/colour-chile'
        },
    ];

    return (
        <div className="app-container">
            <div className="promo-section">
                <div className="promo-content">
                    <h1>Get the best of nature, directly from the farm to your kitchen.</h1>
                    <div className="features">
                        <div className="feature-item">
                            <i className="fa fa-leaf"></i>
                            <p>Farm to Door</p>
                        </div>
                        <div className="feature-item">
                            <i className="fa fa-map-marker"></i>
                            <p>Traceable</p>
                        </div>
                        <div className="feature-item">
                            <i className="fa fa-refresh"></i>
                            <p>Ozone-Washed</p>
                        </div>
                        <div className="feature-item">
                            <i className="fa fa-seedling"></i>
                            <p>Non-GMO</p>
                        </div>
                    </div>
                    <br />
                    <div className="download-section">
                        <p>Download App</p>
                        <div className="download-buttons">
                            <img src="https://wotoapp.com/assets/googleplay.png" alt="Google Play" />
                            <img src="https://th.bing.com/th/id/OIP.CPzmq3SUofVO04i1LKMXUAHaCN?rs=1&pid=ImgDetMain" alt="App Store" />
                        </div>
                        <div className="offer-box">
                            <Link to="/Offerdetails">
                                <button className="offer-button">Today's Offer</button>
                            </Link>
                        </div>
                    </div>
                </div>
                <div className="promo-image">
                    <img src="https://media.healthyfood.com/wp-content/uploads/2021/08/50-easy-ways-to-eat-more-fruit-and-veg-iStock-1225383160.jpg" alt="Fruits and Vegetables" />
                </div>
            </div>

            <div className="c">
                <h2 style={{
                    fontSize: "30px",
                    color: "#4A90E2",
                    textAlign: "center",
                    fontWeight: "bold",
                    margin: "20px 0",
                    textTransform: "uppercase",
                    textShadow: "2px 2px 4px rgba(0, 0, 0, 0.2)"
                }}>
                    Cities We Serve
                </h2>
                <div className="x">
                    <div className="y">
                        <img src="https://pluckk.in/images/city-mumbai.svg" alt="Mumbai" className="city-icon" />
                        <p>Mumbai</p>
                    </div>
                    <div className="z">
                        <img src="https://pluckk.in/images/city-banglore.svg" alt="Bangalore" className="city-icon" />
                        <p>Bangalore</p>
                    </div>
                    <div className="v">
                        <img src="https://pluckk.in/images/city-delhi.svg" alt="Delhi" className="city-icon" />
                        <p>Delhi</p>
                    </div>
                </div>
            </div>

            <div className="container">
                <h2 style={{ fontSize: '30px', color: '#4A90E2', textAlign: 'center' }}>BEST SELLERS</h2>
                <div className="row" style={{ display: 'flex', justifyContent: 'flex-start' }}>
                    {fruits.map((fruit) => (
                        <div className="col" key={fruit.id} style={{ margin: '10px' }}>
                            <div className="card p-3" style={{ width: '300px' }}>
                                <div className="image-container" style={{ textAlign: 'center' }}>
                                    <Link to={fruit.link}>
                                        <img
                                            className="card-img-top"
                                            src={process.env.PUBLIC_URL + '/' + fruit.image}
                                            alt={fruit.name}
                                            onError={(e) => { e.target.onerror = null; e.target.src = 'fallback-image.jpg'; }}
                                            style={{ width: '100%' }}
                                        />
                                    </Link>
                                    {fruit.discount && <div className="discount">{fruit.discount}</div>}
                                </div>
                                <div className="card-body">
                                    <h4 className="card-title" style={{ fontSize: '18px' }}>{fruit.name}</h4>
                                    <p className="description" style={{ fontSize: '14px' }}>{fruit.description}</p>
                                    <p className="size" style={{ fontSize: '12px' }}>{fruit.size}</p>
                                    <div className="price-container">
                                        <span className="price" style={{
                                            fontSize: '20px',
                                            color: 'white',
                                            backgroundColor: 'red',
                                            padding: '5px 10px',
                                            borderRadius: '5px',
                                            marginBottom: '10px',
                                            fontFamily: 'cursive'
                                        }}>
                                            Current Price: ₹{fruit.price}
                                        </span><br />
                                        <span className="original-price" style={{
                                            fontSize: '15px',
                                            color: 'white',
                                            backgroundColor: 'orange',
                                            textDecoration: 'line-through',
                                            padding: '5px 10px',
                                            borderRadius: '5px',
                                            fontFamily: 'cursive'
                                        }}>
                                            Original Price: ₹{fruit.originalPrice}
                                        </span>
                                    </div>
                                   
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            <div className="categories-container">
    <h2 className="category-title">Essentials</h2>
    <div className="categories-grid">
        <Link to="/Vegetabledetails">
            <div className="category-item">
                <img src={process.env.PUBLIC_URL + '/veg.jpg'} alt="Veggies" />
               
            </div>
        </Link>
        <Link to="/Fruitdetail">
            <div className="category-item">
                <img src={process.env.PUBLIC_URL + '/fruits.jpg'} alt="Fruits" />
               
            </div>
        </Link>
    </div>
</div>

            <footer className="footer">
      <div className="footer-container">
      <div className="footer-box">
      <img src="https://media.istockphoto.com/vectors/fruit-icon-vector-id898971502?k=6&m=898971502&s=612x612&w=0&h=gCtibKHPYjNQ3dwHW6FvLEurnb2eZTvjqJ7hOwvAra0=" alt="Shop Icon" className="fs-icon" />
      
        
          <h6>It's time to #EatGoodDoGreat.
Better Fruits & Vegetables starts with MP. Sign up today to enjoy the our experience</h6>
        </div>

        <div className="footer-box">
          <h4>Company Info</h4>
          <ul>
            <li>About Us</li>
            <li>Careers</li>
            <li>Blog</li>
            <li>Press</li>
          </ul>
        </div>
        <div className="footer-box">
          <h4>Contact Info</h4>
          <ul>
            <li>Email: info@example.com</li>
            <li>Phone: +123 456 7890</li>
          </ul>
        </div>
        <div className="footer-box">
          <h4>Address</h4>
          <ul>
            <li>1234 Main St</li>
            <li>City, State 56789</li>
            <li>Country</li>
          </ul>
        </div>
        <div className="footer-box">
          <h4>Follow Us</h4>
          <ul className="social-links">
            <li><a href="https://facebook.com">Facebook</a></li>
            <li><a href="https://twitter.com">Twitter</a></li>
            <li><a href="https://instagram.com">Instagram</a></li>
            <li><a href="https://linkedin.com">LinkedIn</a></li>
          </ul>
        </div>
        <div className="footer-box">
          <h4>Newsletter</h4>
          <form>
            <input type="email" placeholder="Your email" className="newsletter-input" />
            <button type="submit" className="newsletter-btn">Subscribe</button>
          </form>
        </div>
      </div>
      <div className="footer-bottom">
        <p>© 2024 Fruit and Vegetable Shop. All Rights Reserved.</p>
      </div>
    </footer>
        </div>
    );
};
