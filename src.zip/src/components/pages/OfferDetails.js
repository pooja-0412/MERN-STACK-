import React from 'react';


const OfferDetails = () => {
  return (
    <div className="offer-details-container green-bg">
      <header className="header green-bg">
        <h1>SPECIAL OFFER FOR CUSTOMER</h1>
        <p>GET THE OFFER AND ENJOY</p>
      </header>

      <section className="discount-banner yellow-bg">
        <p>DISCOUNT UP TO</p>
        <h2>50%</h2>
      </section>

      <div className="products-grid">
        {/* Product 1 */}
        <div className="product-card green-border">
          <div className="discount red-bg">SALE 30%</div>
          <div className="offer-tag yellow-bg">BUY 1 GET 1</div>
          <img src="avocado.jpg" alt="Avocado" />
          <p className="product-name">Avocado</p>
          <p className="price">300</p>
        </div>

        {/* Product 2 */}
        <div className="product-card yellow-border">
          <div className="discount red-bg">SALE 30%</div>
          <div className="offer-tag yellow-bg">BUY 1 GET 1</div>
          <img src="fig.jpg" alt="Tomato" />
          <p className="product-name">fig fruit</p>
          <p className="price">400</p>
        </div>

        {/* Product 3 */}
        <div className="product-card green-border">
          <div className="discount red-bg">SALE 30%</div>
          <div className="offer-tag yellow-bg">BUY 1 GET 1</div>
          <img src="banana.jpg" alt="Banana" />
          <p className="product-name">Banana</p>
          <p className="price">60</p>
        </div>

        {/* Product 4 */}
        <div className="product-card green-border">
          <div className="discount red-bg">SALE 30%</div>
          <div className="offer-tag yellow-bg">BUY 1 GET 1</div>
          <img src="pineapple.jpg" alt="Passion Fruit" />
          <p className="product-name">PineApple</p>
          <p className="price">80</p>
        </div>

        {/* Product 5 */}
        <div className="product-card green-border">
          <div className="discount red-bg">SALE 30%</div>
          <div className="offer-tag yellow-bg">BUY 1 GET 1</div>
          <img src="jackfruit.jpg" alt="Kiwi" />
          <p className="product-name">jackfruit</p>
          <p className="price">300</p>
        </div>

        {/* Product 6 */}
        <div className="product-card green-border">
          <div className="discount red-bg">SALE 30%</div>
          <div className="offer-tag yellow-bg">BUY 1 GET 1</div>
          <img src="quince.jpg" alt="Guava" />
          <p className="product-name">Quince</p>
          <p className="price">350</p>
        </div>
      </div>

      <footer className="footers green-bg">
        <p>+12 345 6780 | www.MP.com</p>
      </footer>
    </div>
  );
};

export default OfferDetails;
