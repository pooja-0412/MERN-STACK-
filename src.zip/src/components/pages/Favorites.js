// src/components/Favorites.js
import React, { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import axios from 'axios';

export const Favorites = () => {
    const [selectedFruits, setSelectedFruits] = useState([]);
    const navigate = useNavigate();
    const location = useLocation();

    useEffect(() => {
        const { selectedFruits: newFruits } = location.state || {};
        if (newFruits) {
            setSelectedFruits(newFruits.map(fruit => ({ ...fruit, quantity: 1 }))); // Initialize quantity to 1
        }
    }, [location]);

    const handleQuantityChange = (id, quantity) => {
        const updatedFruits = selectedFruits.map(fruit =>
            fruit.id === id ? { ...fruit, quantity: Math.max(1, Number(quantity)) } : fruit
        );
        setSelectedFruits(updatedFruits);
    };

    const handleDelete = (id) => {
        const updatedFruits = selectedFruits.filter(fruit => fruit.id !== id);
        setSelectedFruits(updatedFruits);
    };

    const handleUpdate = () => {
        navigate('/shop', { state: { selectedFruits } }); // Pass selected fruits to shop
    };

    const handlePlaceOrder = async () => {
        const orderDetails = selectedFruits
            .filter(fruit => fruit.quantity > 0)
            .map(fruit => ({
                name: fruit.name,
                price: fruit.price,
                quantity: fruit.quantity,
            }));

        console.log("Order Details Sent to Backend:", orderDetails);

        try {
            const response = await axios.post('http://localhost:5002/api/orderitems', { items: orderDetails });

            console.log(response.data);
            alert('Order placed successfully!');
            navigate('/account', { state: { orderDetails } });
            setSelectedFruits([]); // Clear selected fruits after placing the order
        } catch (error) {
            console.error('Error placing order:', error);
            alert('Failed to place order: ' + error.message); // Improved error message
        }
    };

    const totalItems = selectedFruits.reduce((sum, fruit) => sum + fruit.quantity, 0);

    return (
        <div className="favoritescontainer">
            <h2>Your Favorites</h2>
            {selectedFruits.length > 0 ? (
                <div className="favorites-list">
                    {selectedFruits.map((fruit) => (
                        <div className="favorite-item" key={fruit.id}>
                            <img src={process.env.PUBLIC_URL + '/' + fruit.image} alt={fruit.name} className="favorite-image" />
                            <div className="favorite-details">
                                <h4>{fruit.name}</h4>
                                <p>Price: ₹{fruit.price}</p>
                                <input
                                    type="number"
                                    min="1"
                                    value={fruit.quantity || 1}
                                    onChange={(e) => handleQuantityChange(fruit.id, e.target.value)}
                                />
                                <button className="btn btn-danger" onClick={() => handleDelete(fruit.id)}>Delete</button>
                            </div>
                        </div>
                    ))}
                    <p>Total Items: {totalItems}</p>
                    
                    {/* Single Update Button */}
                    <button className="btn btn-secondary" onClick={handleUpdate}>
                        Update Items
                    </button>

                    {/* Place Order Button */}
                    <button className="btn btn-primary" onClick={handlePlaceOrder} style={{ marginTop: '20px' }}>
                        Place Order
                    </button>
                </div>
            ) : (
                <p>No favorites added yet!</p>
            )}
        </div>
    );
};

export default Favorites;
