import React from 'react';
import { NavLink } from "react-router-dom";
import './Navbar.css'; // Ensure the CSS file is correctly linked

export const Navbar = () => {
    return (
        <nav className="navbar">
            <div className="navbar-left">
                <ul>
                    <img src="nav.jpg" alt="Shop Icon" className="fs-icon" />
                </ul>
            </div>

            <div className="center-align search-container">
                <form action="/action_page.php">
                    <input type="text" placeholder="Search for fruits..." name="search" />
                </form>
            </div>

            <div className="navbar-right">
                <ul>
                    <li>
                        <NavLink to="/home">
                            <img src="https://static.vecteezy.com/system/resources/previews/000/425/085/original/house-icon-vector-illustration.jpg" alt="Shop Icon" className="nav-icon" />
                            home
                        </NavLink>
                    </li>
                    <li>
                        <NavLink to="/shop">
                            <img src="https://im.pluckk.in/unsafe/40x0/dev-uploads/4076-frame-22395.png" alt="Shop Icon" className="nav-icon" />
                            Shop
                        </NavLink>
                    </li>
                    <li>
                        <NavLink to="/account">
                            <img src="https://im.pluckk.in/unsafe/40x0/dev-uploads/4075-group-22650.png" alt="Account Icon" className="nav-icon" />
                            Account
                        </NavLink>
                    </li>
                    <li>
                        <NavLink to="/favorites">
                            <img src="https://colouringpages.guru/wp-content/uploads/colorings/19/heart-suit-emoji-coloring-page-print-4-768x768.png" alt="Account Icon" className="nav-icon" />
                            favorite
                        </NavLink>
                    </li>
                </ul>
            </div>
        </nav>
    );
};
